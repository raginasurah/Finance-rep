import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, PieChart, Pie, Cell, BarChart, Bar, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, CircleDollarSign, Upload, MessageSquare, Calculator, Brain, FileSpreadsheet, Wallet, Target, CreditCard, Plus, Edit2, Trash2, Bell, Shield, PiggyBank, BookOpen, Lightbulb, AlertTriangle, CheckCircle, Clock, Calendar, Zap, BarChart3, Activity } from 'lucide-react';

const AIFinancialApp = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [chatMessages, setChatMessages] = useState([]);
  const [chatInput, setChatInput] = useState('');
  const [portfolio, setPortfolio] = useState([]);
  const [uploadedData, setUploadedData] = useState(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  
  // Expenses state
  const [expenses, setExpenses] = useState([]);
  
  const [newExpense, setNewExpense] = useState({
    name: '',
    amount: '',
    category: 'Housing',
    frequency: 'Monthly',
    dueDate: ''
  });
  
  const [showAddExpense, setShowAddExpense] = useState(false);
  const [editingExpense, setEditingExpense] = useState(null);
  const [editExpenseData, setEditExpenseData] = useState({
    name: '',
    amount: '',
    category: 'Housing',
    frequency: 'Monthly',
    dueDate: ''
  });
  
  // Investment & Savings state
  const [savings, setSavings] = useState([]);
  
  const [watchlist, setWatchlist] = useState([]);
  
  const [transactions, setTransactions] = useState([]);
  
  const [newTransaction, setNewTransaction] = useState({
    type: 'Buy',
    symbol: '',
    shares: '',
    price: '',
    date: new Date().toISOString().split('T')[0]
  });
  
  const [showAddTransaction, setShowAddTransaction] = useState(false);
  
  // Advanced features state
  const [budgets, setBudgets] = useState([]);
  
  const [debts, setDebts] = useState([]);
  
  const [financialHealth, setFinancialHealth] = useState({
    score: 0,
    factors: [
      { name: 'Emergency Fund', score: 0, status: 'needs-improvement' },
      { name: 'Debt-to-Income', score: 0, status: 'needs-improvement' },
      { name: 'Savings Rate', score: 0, status: 'needs-improvement' },
      { name: 'Investment Diversity', score: 0, status: 'needs-improvement' }
    ]
  });
  
  const [notifications, setNotifications] = useState([]);

  const totalPortfolioValue = portfolio.reduce((sum, stock) => sum + stock.value, 0);
  const totalSavings = savings.reduce((sum, account) => sum + account.balance, 0);
  const totalDebts = debts.reduce((sum, debt) => sum + debt.balance, 0);
  const netWorth = totalPortfolioValue + totalSavings - totalDebts;
  
  // Format date for display
  const formatDate = (dateStr) => {
    if (dateStr === 'Ongoing' || !dateStr) return dateStr || 'Not set';
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  };

  // Calculate total monthly expenses
  const calculateMonthlyExpenses = () => {
    return expenses.reduce((total, expense) => {
      switch (expense.frequency) {
        case 'Weekly': return total + (expense.amount * 52 / 12);
        case 'Monthly': return total + expense.amount;
        case 'Quarterly': return total + (expense.amount / 3);
        case 'Yearly': return total + (expense.amount / 12);
        default: return total + expense.amount;
      }
    }, 0);
  };
  
  const monthlyExpenses = calculateMonthlyExpenses();
  
  // Expense functions
  const addExpense = () => {
    if (newExpense.name && newExpense.amount) {
      const expense = {
        id: Date.now(),
        name: newExpense.name,
        amount: parseFloat(newExpense.amount),
        category: newExpense.category,
        frequency: newExpense.frequency,
        dueDate: newExpense.dueDate || 'Not set'
      };
      setExpenses([...expenses, expense]);
      setNewExpense({ name: '', amount: '', category: 'Housing', frequency: 'Monthly', dueDate: '' });
      setShowAddExpense(false);
    }
  };
  
  const deleteExpense = (id) => {
    setExpenses(expenses.filter(expense => expense.id !== id));
  };
  
  const startEditExpense = (expense) => {
    setEditingExpense(expense.id);
    setEditExpenseData({
      name: expense.name,
      amount: expense.amount.toString(),
      category: expense.category,
      frequency: expense.frequency,
      dueDate: expense.dueDate === 'Ongoing' || expense.dueDate === 'Not set' ? '' : expense.dueDate
    });
    setShowAddExpense(false);
  };
  
  const saveEditExpense = () => {
    if (editExpenseData.name && editExpenseData.amount) {
      setExpenses(expenses.map(expense => 
        expense.id === editingExpense 
          ? {
              ...expense,
              name: editExpenseData.name,
              amount: parseFloat(editExpenseData.amount),
              category: editExpenseData.category,
              frequency: editExpenseData.frequency,
              dueDate: editExpenseData.dueDate || 'Not set'
            }
          : expense
      ));
      setEditingExpense(null);
      setEditExpenseData({ name: '', amount: '', category: 'Housing', frequency: 'Monthly', dueDate: '' });
    }
  };
  
  const cancelEditExpense = () => {
    setEditingExpense(null);
    setEditExpenseData({ name: '', amount: '', category: 'Housing', frequency: 'Monthly', dueDate: '' });
  };
  
  // Investment functions
  const addTransaction = () => {
    if (newTransaction.symbol && newTransaction.shares && newTransaction.price) {
      const transaction = {
        id: Date.now(),
        date: newTransaction.date,
        type: newTransaction.type,
        symbol: newTransaction.symbol.toUpperCase(),
        shares: parseInt(newTransaction.shares),
        price: parseFloat(newTransaction.price),
        total: newTransaction.type === 'Dividend' ? parseFloat(newTransaction.price) : parseInt(newTransaction.shares) * parseFloat(newTransaction.price)
      };
      setTransactions([transaction, ...transactions]);
      setNewTransaction({
        type: 'Buy',
        symbol: '',
        shares: '',
        price: '',
        date: new Date().toISOString().split('T')[0]
      });
      setShowAddTransaction(false);
      
      // Update portfolio if it's a buy/sell
      if (newTransaction.type === 'Buy') {
        const existingStock = portfolio.find(stock => stock.symbol === transaction.symbol);
        if (existingStock) {
          setPortfolio(portfolio.map(stock => 
            stock.symbol === transaction.symbol 
              ? { ...stock, shares: stock.shares + transaction.shares, value: (stock.shares + transaction.shares) * stock.price }
              : stock
          ));
        } else {
          setPortfolio([...portfolio, {
            symbol: transaction.symbol,
            shares: transaction.shares,
            price: transaction.price,
            value: transaction.total
          }]);
        }
      }
    }
  };
  
  const addToWatchlist = (symbol) => {
    const newStock = {
      symbol: symbol.toUpperCase(),
      name: `${symbol.toUpperCase()} Corp`,
      price: Math.floor(Math.random() * 500) + 50,
      change: (Math.random() - 0.5) * 20,
      changePercent: (Math.random() - 0.5) * 5
    };
    setWatchlist([...watchlist, newStock]);
  };
  
  // Group expenses by category for chart
  const expensesByCategory = ['Housing', 'Transport', 'Food', 'Utilities', 'Subscriptions', 'Entertainment', 'Healthcare', 'Shopping', 'Insurance', 'Other'].map(category => {
    const categoryExpenses = expenses.filter(exp => exp.category === category);
    const total = categoryExpenses.reduce((sum, exp) => {
      switch (exp.frequency) {
        case 'Weekly': return sum + (exp.amount * 52 / 12);
        case 'Monthly': return sum + exp.amount;
        case 'Quarterly': return sum + (exp.amount / 3);
        case 'Yearly': return sum + (exp.amount / 12);
        default: return sum + exp.amount;
      }
    }, 0);
    return { name: category, value: total, count: categoryExpenses.length };
  }).filter(item => item.value > 0);

  // Mock market data
  const marketData = [
    { date: '2025-01', portfolio: 0, sp500: 21500 },
    { date: '2025-02', portfolio: 0, sp500: 22000 },
    { date: '2025-03', portfolio: 0, sp500: 22800 },
    { date: '2025-04', portfolio: 0, sp500: 23200 },
    { date: '2025-05', portfolio: 0, sp500: 24100 },
    { date: '2025-06', portfolio: 0, sp500: 23900 },
    { date: '2025-07', portfolio: 0, sp500: 24800 }
  ];

  const sectorData = [];

  // Advanced offline AI system
  const financialKnowledgeBase = {
    budgeting: {
      rules: ['50/30/20 rule', 'Zero-based budgeting', 'Envelope method'],
      tips: ['Track every expense', 'Use budgeting apps', 'Review monthly', 'Automate savings']
    },
    investing: {
      principles: ['Diversification', 'Dollar-cost averaging', 'Long-term thinking', 'Risk tolerance'],
      advice: ['Start early', 'Invest regularly', 'Rebalance portfolio', 'Stay informed']
    },
    savings: {
      strategies: ['Emergency fund first', 'High-yield accounts', 'Automatic transfers', 'Goal-based saving'],
      emergency: 'Aim for 3-6 months of expenses in emergency fund'
    },
    debt: {
      strategies: ['Debt avalanche', 'Debt snowball', 'Consolidation', 'Balance transfers'],
      priority: 'Pay high-interest debt first'
    }
  };

  const analyzeUserData = () => {
    const analysis = {
      savingsRate: ((totalSavings / (monthlyExpenses * 12)) * 100).toFixed(1),
      debtToIncome: ((totalDebts / (monthlyExpenses * 12)) * 100).toFixed(1),
      emergencyMonths: (totalSavings / monthlyExpenses).toFixed(1),
      portfolioAllocation: portfolio.map(stock => ({
        symbol: stock.symbol,
        percentage: ((stock.value / totalPortitalioValue) * 100).toFixed(1)
      }))
    };
    return analysis;
  };

  const generateOfflineAIResponse = (input) => {
    const lowerInput = input.toLowerCase();
    const userAnalysis = analyzeUserData();
    
    // Handle empty data scenarios
    if (portfolio.length === 0 && expenses.length === 0 && savings.length === 0) {
      return `Welcome to your AI Financial Assistant! I'm here to help you manage your finances. Start by adding some data:\n\n• Add expenses to track spending\n• Record investment transactions\n• Set up savings accounts\n• Define your budget\n\nOnce you have some data, I can provide personalized insights and recommendations!`;
    }
    
    // Pattern matching for different financial topics
    if (lowerInput.includes('budget') || lowerInput.includes('spending')) {
      if (expenses.length === 0) {
        return `You haven't added any expenses yet. Start by clicking 'Add Expense' to track your spending. Once you have data, I can help you create and optimize your budget using proven strategies like the 50/30/20 rule.`;
      }
      const overspentCategories = budgets.filter(b => b.spent > b.allocated);
      if (overspentCategories.length > 0) {
        return `Budget Analysis: You've overspent in ${overspentCategories.map(c => c.category).join(', ')}. Your total monthly expenses are £${monthlyExpenses.toFixed(2)}. Consider the 50/30/20 rule: 50% needs, 30% wants, 20% savings. ${financialKnowledgeBase.budgeting.tips[Math.floor(Math.random() * financialKnowledgeBase.budgeting.tips.length)]}`;
      }
      return `Budget Status: You're tracking £${monthlyExpenses.toFixed(2)} in monthly expenses. ${financialKnowledgeBase.budgeting.tips[Math.floor(Math.random() * financialKnowledgeBase.budgeting.tips.length)]}`;
    }
    
    if (lowerInput.includes('invest') || lowerInput.includes('portfolio')) {
      if (portfolio.length === 0) {
        return `You haven't added any investments yet. Start by recording transactions in the Savings tab. Key investing principles: ${financialKnowledgeBase.investing.principles.join(', ')}. ${financialKnowledgeBase.investing.advice[Math.floor(Math.random() * financialKnowledgeBase.investing.advice.length)]}`;
      }
      return `Portfolio Analysis: Your portfolio is worth ${totalPortfolioValue.toLocaleString()}. ${financialKnowledgeBase.investing.advice[Math.floor(Math.random() * financialKnowledgeBase.investing.advice.length)]}. Key principle: ${financialKnowledgeBase.investing.principles[Math.floor(Math.random() * financialKnowledgeBase.investing.principles.length)]}`;
    }
    
    if (lowerInput.includes('save') || lowerInput.includes('emergency')) {
      if (savings.length === 0) {
        return `You haven't set up any savings accounts yet. ${financialKnowledgeBase.savings.emergency} Start by adding accounts in the Savings tab. Strategy: ${financialKnowledgeBase.savings.strategies[Math.floor(Math.random() * financialKnowledgeBase.savings.strategies.length)]}`;
      }
      const emergencyMonths = totalSavings > 0 ? (totalSavings / Math.max(monthlyExpenses, 1)).toFixed(1) : 0;
      if (emergencyMonths < 3) {
        return `Emergency Fund: You have ${emergencyMonths} months of expenses saved (£${totalSavings.toLocaleString()}). ${financialKnowledgeBase.savings.emergency} Strategy: ${financialKnowledgeBase.savings.strategies[Math.floor(Math.random() * financialKnowledgeBase.savings.strategies.length)]}`;
      }
      return `Savings Status: Great! You have ${emergencyMonths} months of expenses saved (£${totalSavings.toLocaleString()}). ${financialKnowledgeBase.savings.strategies[Math.floor(Math.random() * financialKnowledgeBase.savings.strategies.length)]}`;
    }
    
    if (lowerInput.includes('debt') || lowerInput.includes('loan') || lowerInput.includes('credit')) {
      if (debts.length === 0) {
        return `Great! You don't have any tracked debts. Keep it up and avoid high-interest debt. If you do have debts, add them to get personalized payoff strategies.`;
      }
      const highestDebt = debts.reduce((max, debt) => debt.balance > max.balance ? debt : max, debts[0]);
      return `Debt Analysis: Total debt: £${totalDebts.toLocaleString()}. Highest: ${highestDebt.name} at ${highestDebt.rate}% rate. ${financialKnowledgeBase.debt.priority} Strategy: ${financialKnowledgeBase.debt.strategies[Math.floor(Math.random() * financialKnowledgeBase.debt.strategies.length)]}`;
    }
    
    if (lowerInput.includes('health') || lowerInput.includes('score')) {
      return `Financial Health Score: ${financialHealth.score}/100. Check the Health Score tab for detailed breakdown and improvement recommendations.`;
    }
    
    if (lowerInput.includes('goal') || lowerInput.includes('target')) {
      if (savings.length === 0) {
        return `You haven't set any savings goals yet. Go to the Goals tab to set targets for emergency fund, house deposit, retirement, or other objectives.`;
      }
      return `Goal Progress: Track your progress in the Goals tab. Set specific, measurable targets and automate your savings to reach them faster.`;
    }
    
    if (lowerInput.includes('tip') || lowerInput.includes('advice') || lowerInput.includes('help')) {
      const randomTips = [
        `Start by tracking all your expenses to understand your spending patterns.`,
        `Set up automatic transfers to savings accounts to pay yourself first.`,
        `Build an emergency fund before investing - aim for 3-6 months of expenses.`,
        `Review your subscriptions monthly and cancel unused services.`,
        `Use the 50/30/20 rule: 50% needs, 30% wants, 20% savings and debt repayment.`,
        `Diversify your investments across different asset classes and sectors.`,
        `Take advantage of employer 401k matching - it's free money.`,
        `Track your net worth monthly to monitor overall financial progress.`
      ];
      return randomTips[Math.floor(Math.random() * randomTips.length)];
    }
    
    // Default response for getting started
    if (portfolio.length === 0 && expenses.length === 0 && savings.length === 0) {
      return `I'm your personal financial AI assistant! I can help you with budgeting, investing, saving, debt management, and goal planning. Start by adding some financial data, then ask me for personalized advice!`;
    }
    
    // Default comprehensive response
    return `Financial Summary: Net Worth: £${netWorth.toLocaleString()} | Portfolio: ${totalPortfolioValue.toLocaleString()} | Savings: £${totalSavings.toLocaleString()} | Monthly Expenses: £${monthlyExpenses.toFixed(2)} | Health Score: ${financialHealth.score}/100. Ask me about budgeting, investing, saving strategies, debt management, or goal planning!`;
  };

  // AI Chat functionality with offline capabilities
  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;

    const userMessage = { role: 'user', content: chatInput };
    setChatMessages(prev => [...prev, userMessage]);
    setChatInput('');

    // Simulate thinking time for offline AI
    setTimeout(() => {
      const aiResponse = generateOfflineAIResponse(chatInput);
      setChatMessages(prev => [...prev, { role: 'assistant', content: aiResponse }]);
    }, 800);
  };

  // File upload handler
  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsAnalyzing(true);
    
    setTimeout(() => {
      const mockAnalysis = {
        filename: file.name,
        summary: "Analysis complete! Found 245 transactions across 12 categories.",
        insights: [
          "Monthly spending average: £3,240",
          "Largest expense category: Housing (42%)",
          "Investment contributions: £850/month",
          "Potential savings identified: £320/month"
        ],
        recommendations: [
          "Reduce dining out expenses by 20% to save £180/month",
          "Increase emergency fund to 6 months expenses",
          "Consider automating investments to dollar-cost average"
        ]
      };
      setUploadedData(mockAnalysis);
      setIsAnalyzing(false);
    }, 2000);
  };

  // Financial Calculator
  const [calcType, setCalcType] = useState('compound');
  const [calcInputs, setCalcInputs] = useState({
    principal: 10000,
    rate: 7,
    time: 10,
    compounds: 12
  });

  const calculateCompoundInterest = () => {
    const { principal, rate, time, compounds } = calcInputs;
    const amount = principal * Math.pow((1 + rate/100/compounds), compounds * time);
    return amount.toFixed(2);
  };

  const expenseCategories = ['Housing', 'Transport', 'Food', 'Utilities', 'Subscriptions', 'Entertainment', 'Healthcare', 'Shopping', 'Insurance', 'Other'];
  const frequencies = ['Weekly', 'Monthly', 'Quarterly', 'Yearly'];

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
    { id: 'portfolio', label: 'Portfolio', icon: CircleDollarSign },
    { id: 'savings', label: 'Savings', icon: Wallet },
    { id: 'expenses', label: 'Expenses', icon: CreditCard },
    { id: 'budget', label: 'Budget', icon: BarChart3 },
    { id: 'health', label: 'Health Score', icon: Activity },
    { id: 'chat', label: 'AI Assistant', icon: Brain },
    { id: 'analysis', label: 'File Analysis', icon: FileSpreadsheet },
    { id: 'calculator', label: 'Calculator', icon: Calculator },
    { id: 'goals', label: 'Goals', icon: Target }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">AI Financial Hub Pro</h1>
                <p className="text-sm text-gray-600">Advanced financial management with offline AI</p>
              </div>
            </div>
            <div className="flex items-center space-x-6">
              <div className="text-sm text-gray-600 space-x-4">
                <span>Net Worth: <span className="font-semibold text-green-600">£{netWorth.toLocaleString()}</span></span>
                <span>Health Score: <span className="font-semibold text-blue-600">{financialHealth.score}/100</span></span>
              </div>
              <div className="relative">
                <Bell className="w-6 h-6 text-gray-600 cursor-pointer" />
                {notifications.length > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {notifications.length}
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white shadow-sm min-h-screen border-r">
          <div className="p-4">
            <div className="space-y-2">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-blue-50 text-blue-700 border border-blue-200'
                        : 'text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{tab.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Net Worth</p>
                      <p className="text-2xl font-bold text-gray-900">£{netWorth.toLocaleString()}</p>
                    </div>
                    <div className="bg-green-100 p-3 rounded-full">
                      <TrendingUp className="w-6 h-6 text-green-600" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-sm">
                    <span className="text-green-600 font-medium">+8.2%</span>
                    <span className="text-gray-600 ml-2">this month</span>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Portfolio</p>
                      <p className="text-2xl font-bold text-gray-900">${totalPortfolioValue.toLocaleString()}</p>
                    </div>
                    <div className="bg-blue-100 p-3 rounded-full">
                      <CircleDollarSign className="w-6 h-6 text-blue-600" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-sm">
                    <span className="text-blue-600 font-medium">+9.7%</span>
                    <span className="text-gray-600 ml-2">vs S&P 500</span>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Savings</p>
                      <p className="text-2xl font-bold text-gray-900">£{totalSavings.toLocaleString()}</p>
                    </div>
                    <div className="bg-purple-100 p-3 rounded-full">
                      <PiggyBank className="w-6 h-6 text-purple-600" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-sm">
                    <span className="text-purple-600 font-medium">{savings.length} accounts</span>
                    <span className="text-gray-600 ml-2">active</span>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Monthly Expenses</p>
                      <p className="text-2xl font-bold text-gray-900">£{monthlyExpenses.toFixed(2)}</p>
                    </div>
                    <div className="bg-red-100 p-3 rounded-full">
                      <CreditCard className="w-6 h-6 text-red-600" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-sm">
                    <span className="text-red-600 font-medium">{expenses.length} items</span>
                    <span className="text-gray-600 ml-2">tracked</span>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Health Score</p>
                      <p className="text-2xl font-bold text-gray-900">{financialHealth.score}/100</p>
                    </div>
                    <div className="bg-orange-100 p-3 rounded-full">
                      <Activity className="w-6 h-6 text-orange-600" />
                    </div>
                  </div>
                  <div className="mt-4 flex items-center text-sm">
                    <span className="text-orange-600 font-medium">Good</span>
                    <span className="text-gray-600 ml-2">financial health</span>
                  </div>
                </div>
              </div>

              {/* Notifications Panel */}
              {notifications.length > 0 && (
                <div className="bg-white rounded-xl shadow-sm border p-6">
                  <h3 className="text-lg font-semibold mb-4 flex items-center">
                    <Bell className="w-5 h-5 mr-2" />
                    Recent Notifications
                  </h3>
                  <div className="space-y-3">
                    {notifications.map((notification) => (
                      <div key={notification.id} className={`flex items-center p-3 rounded-lg ${
                        notification.type === 'warning' ? 'bg-yellow-50 border border-yellow-200' :
                        notification.type === 'success' ? 'bg-green-50 border border-green-200' :
                        'bg-blue-50 border border-blue-200'
                      }`}>
                        {notification.type === 'warning' && <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3" />}
                        {notification.type === 'success' && <CheckCircle className="w-5 h-5 text-green-600 mr-3" />}
                        {notification.type === 'info' && <Lightbulb className="w-5 h-5 text-blue-600 mr-3" />}
                        <div className="flex-1">
                          <p className={`font-medium ${
                            notification.type === 'warning' ? 'text-yellow-800' :
                            notification.type === 'success' ? 'text-green-800' :
                            'text-blue-800'
                          }`}>{notification.message}</p>
                          <p className="text-sm text-gray-600">{notification.date}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <h3 className="text-lg font-semibold mb-4">Portfolio Performance</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={marketData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Line type="monotone" dataKey="portfolio" stroke="#2563eb" strokeWidth={2} name="Your Portfolio" />
                      <Line type="monotone" dataKey="sp500" stroke="#64748b" strokeWidth={2} name="S&P 500" />
                    </LineChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <h3 className="text-lg font-semibold mb-4">Asset Allocation</h3>
                  <ResponsiveContainer width="100%" height={300}>
                    <PieChart>
                      <Pie
                        data={sectorData}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="value"
                      >
                        {sectorData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <h3 className="text-lg font-semibold mb-4">Quick Actions</h3>
                  <div className="space-y-3">
                    <button 
                      onClick={() => setActiveTab('chat')}
                      className="w-full bg-blue-600 text-white px-4 py-3 rounded-lg hover:bg-blue-700 flex items-center"
                    >
                      <Brain className="w-5 h-5 mr-2" />
                      Ask AI Assistant
                    </button>
                    <button 
                      onClick={() => setActiveTab('expenses')}
                      className="w-full bg-green-600 text-white px-4 py-3 rounded-lg hover:bg-green-700 flex items-center"
                    >
                      <Plus className="w-5 h-5 mr-2" />
                      Add Expense
                    </button>
                    <button 
                      onClick={() => setActiveTab('health')}
                      className="w-full bg-purple-600 text-white px-4 py-3 rounded-lg hover:bg-purple-700 flex items-center"
                    >
                      <Activity className="w-5 h-5 mr-2" />
                      Check Health Score
                    </button>
                    <button 
                      onClick={() => setActiveTab('calculator')}
                      className="w-full bg-orange-600 text-white px-4 py-3 rounded-lg hover:bg-orange-700 flex items-center"
                    >
                      <Calculator className="w-5 h-5 mr-2" />
                      Financial Calculator
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'portfolio' && (
            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-xl font-semibold">Portfolio Holdings</h2>
                </div>
                <div className="p-6">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-3 px-4">Symbol</th>
                          <th className="text-left py-3 px-4">Shares</th>
                          <th className="text-left py-3 px-4">Price</th>
                          <th className="text-left py-3 px-4">Value</th>
                          <th className="text-left py-3 px-4">Allocation</th>
                        </tr>
                      </thead>
                      <tbody>
                        {portfolio.map((stock, index) => (
                          <tr key={index} className="border-b hover:bg-gray-50">
                            <td className="py-3 px-4 font-medium">{stock.symbol}</td>
                            <td className="py-3 px-4">{stock.shares}</td>
                            <td className="py-3 px-4">${stock.price}</td>
                            <td className="py-3 px-4">${stock.value.toLocaleString()}</td>
                            <td className="py-3 px-4">
                              <div className="flex items-center">
                                <div className="w-20 bg-gray-200 rounded-full h-2 mr-2">
                                  <div 
                                    className="bg-blue-600 h-2 rounded-full" 
                                    style={{ width: `${(stock.value / totalPortfolioValue) * 100}%` }}
                                  ></div>
                                </div>
                                <span className="text-sm text-gray-600">
                                  {((stock.value / totalPortfolioValue) * 100).toFixed(1)}%
                                </span>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'savings' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <h3 className="text-lg font-semibold mb-4">Savings Accounts</h3>
                  <div className="space-y-3">
                    {savings.map((account) => (
                      <div key={account.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">{account.name}</h4>
                          <span className="text-sm text-gray-600">{account.type}</span>
                        </div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-lg font-bold text-blue-600">£{account.balance.toLocaleString()}</span>
                          <span className="text-sm text-green-600">{account.rate}% APY</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${Math.min((account.balance / account.target) * 100, 100)}%` }}
                          ></div>
                        </div>
                        <div className="flex justify-between text-sm text-gray-600 mt-1">
                          <span>{((account.balance / account.target) * 100).toFixed(1)}% of target</span>
                          <span>Target: £{account.target.toLocaleString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <h3 className="text-lg font-semibold mb-4">Stock Watchlist</h3>
                  <div className="space-y-3">
                    {watchlist.map((stock, index) => (
                      <div key={index} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-bold">{stock.symbol}</h4>
                            <p className="text-sm text-gray-600">{stock.name}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold">${stock.price}</p>
                            <p className={`text-sm ${stock.change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {stock.change >= 0 ? '+' : ''}{stock.change.toFixed(2)} ({stock.changePercent.toFixed(2)}%)
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                    <button
                      onClick={() => {
                        const symbol = prompt('Enter stock symbol to add to watchlist:');
                        if (symbol) addToWatchlist(symbol);
                      }}
                      className="w-full border-2 border-dashed border-gray-300 rounded-lg p-3 text-gray-600 hover:border-blue-400 hover:text-blue-600"
                    >
                      + Add to Watchlist
                    </button>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-xl shadow-sm border">
                  <h3 className="text-lg font-semibold mb-4">Recent Transactions</h3>
                  <div className="space-y-3 max-h-80 overflow-y-auto">
                    {transactions.slice(0, 10).map((transaction) => (
                      <div key={transaction.id} className="border rounded-lg p-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-medium">{transaction.type} {transaction.symbol}</h4>
                            <p className="text-sm text-gray-600">{new Date(transaction.date).toLocaleDateString()}</p>
                          </div>
                          <div className="text-right">
                            {transaction.type !== 'Dividend' && (
                              <p className="text-sm">{transaction.shares} @ ${transaction.price}</p>
                            )}
                            <p className={`font-bold ${transaction.type === 'Buy' ? 'text-red-600' : 'text-green-600'}`}>
                              {transaction.type === 'Buy' ? '-' : '+'}${transaction.total.toFixed(2)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <button
                    onClick={() => setShowAddTransaction(!showAddTransaction)}
                    className="w-full mt-4 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700"
                  >
                    Add Transaction
                  </button>
                  
                  {showAddTransaction && (
                    <div className="mt-4 p-4 border rounded-lg bg-gray-50">
                      <div className="grid grid-cols-2 gap-3">
                        <select
                          value={newTransaction.type}
                          onChange={(e) => setNewTransaction(prev => ({ ...prev, type: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          <option value="Buy">Buy</option>
                          <option value="Sell">Sell</option>
                          <option value="Dividend">Dividend</option>
                        </select>
                        <input
                          type="text"
                          placeholder="Symbol (e.g., AAPL)"
                          value={newTransaction.symbol}
                          onChange={(e) => setNewTransaction(prev => ({ ...prev, symbol: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        {newTransaction.type !== 'Dividend' && (
                          <input
                            type="number"
                            placeholder="Shares"
                            value={newTransaction.shares}
                            onChange={(e) => setNewTransaction(prev => ({ ...prev, shares: e.target.value }))}
                            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        )}
                        <input
                          type="number"
                          placeholder={newTransaction.type === 'Dividend' ? 'Amount ($)' : 'Price per share ($)'}
                          value={newTransaction.price}
                          onChange={(e) => setNewTransaction(prev => ({ ...prev, price: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <input
                          type="date"
                          value={newTransaction.date}
                          onChange={(e) => setNewTransaction(prev => ({ ...prev, date: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <button
                          onClick={addTransaction}
                          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                        >
                          Add Transaction
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'expenses' && (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white p-4 rounded-xl shadow-sm border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Monthly Total</p>
                      <p className="text-xl font-bold text-red-600">£{monthlyExpenses.toFixed(2)}</p>
                    </div>
                    <CreditCard className="w-8 h-8 text-red-500" />
                  </div>
                </div>
                <div className="bg-white p-4 rounded-xl shadow-sm border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Largest Expense</p>
                      <p className="text-xl font-bold text-gray-900">£{Math.max(...expenses.map(e => e.amount))}</p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-blue-500" />
                  </div>
                </div>
                <div className="bg-white p-4 rounded-xl shadow-sm border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Categories</p>
                      <p className="text-xl font-bold text-gray-900">{expensesByCategory.length}</p>
                    </div>
                    <Target className="w-8 h-8 text-green-500" />
                  </div>
                </div>
                <div className="bg-white p-4 rounded-xl shadow-sm border">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600">Total Items</p>
                      <p className="text-xl font-bold text-gray-900">{expenses.length}</p>
                    </div>
                    <FileSpreadsheet className="w-8 h-8 text-purple-500" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white rounded-xl shadow-sm border">
                  <div className="px-6 py-4 border-b flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <h2 className="text-xl font-semibold">Monthly Expenses</h2>
                      {editingExpense && (
                        <span className="bg-yellow-100 text-yellow-800 text-sm px-2 py-1 rounded">
                          Editing Mode
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => {
                        setShowAddExpense(!showAddExpense);
                        setEditingExpense(null);
                      }}
                      disabled={editingExpense !== null}
                      className={`px-4 py-2 rounded-lg flex items-center space-x-2 ${
                        editingExpense !== null 
                          ? 'bg-gray-400 text-gray-600 cursor-not-allowed' 
                          : 'bg-blue-600 text-white hover:bg-blue-700'
                      }`}
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add Expense</span>
                    </button>
                  </div>
                  
                  {showAddExpense && !editingExpense && (
                    <div className="p-6 border-b bg-gray-50">
                      <h3 className="font-medium mb-4">Add New Expense</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <input
                          type="text"
                          placeholder="Expense name"
                          value={newExpense.name}
                          onChange={(e) => setNewExpense(prev => ({ ...prev, name: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <input
                          type="number"
                          placeholder="Amount (£)"
                          value={newExpense.amount}
                          onChange={(e) => setNewExpense(prev => ({ ...prev, amount: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <select
                          value={newExpense.category}
                          onChange={(e) => setNewExpense(prev => ({ ...prev, category: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          {expenseCategories.map(cat => (
                            <option key={cat} value={cat}>{cat}</option>
                          ))}
                        </select>
                        <select
                          value={newExpense.frequency}
                          onChange={(e) => setNewExpense(prev => ({ ...prev, frequency: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        >
                          {frequencies.map(freq => (
                            <option key={freq} value={freq}>{freq}</option>
                          ))}
                        </select>
                        <input
                          type="date"
                          value={newExpense.dueDate}
                          onChange={(e) => setNewExpense(prev => ({ ...prev, dueDate: e.target.value }))}
                          className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                        <button
                          onClick={addExpense}
                          className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700"
                        >
                          Add Expense
                        </button>
                      </div>
                    </div>
                  )}
                  
                  <div className="p-6">
                    <div className="space-y-3">
                      {expenses.map((expense) => (
                        <div key={expense.id} className={`p-3 rounded-lg ${
                          editingExpense === expense.id 
                            ? 'bg-blue-50 border-2 border-blue-200' 
                            : 'bg-gray-50'
                        }`}>
                          {editingExpense === expense.id ? (
                            <div className="space-y-3">
                              <div className="grid grid-cols-2 gap-3">
                                <input
                                  type="text"
                                  value={editExpenseData.name}
                                  onChange={(e) => setEditExpenseData(prev => ({ ...prev, name: e.target.value }))}
                                  onKeyPress={(e) => e.key === 'Enter' && saveEditExpense()}
                                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  placeholder="Expense name"
                                />
                                <input
                                  type="number"
                                  value={editExpenseData.amount}
                                  onChange={(e) => setEditExpenseData(prev => ({ ...prev, amount: e.target.value }))}
                                  onKeyPress={(e) => e.key === 'Enter' && saveEditExpense()}
                                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                  placeholder="Amount (£)"
                                />
                                <select
                                  value={editExpenseData.category}
                                  onChange={(e) => setEditExpenseData(prev => ({ ...prev, category: e.target.value }))}
                                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                  {expenseCategories.map(cat => (
                                    <option key={cat} value={cat}>{cat}</option>
                                  ))}
                                </select>
                                <select
                                  value={editExpenseData.frequency}
                                  onChange={(e) => setEditExpenseData(prev => ({ ...prev, frequency: e.target.value }))}
                                  className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                  {frequencies.map(freq => (
                                    <option key={freq} value={freq}>{freq}</option>
                                  ))}
                                </select>
                              </div>
                              <input
                                type="date"
                                value={editExpenseData.dueDate}
                                onChange={(e) => setEditExpenseData(prev => ({ ...prev, dueDate: e.target.value }))}
                                onKeyPress={(e) => e.key === 'Enter' && saveEditExpense()}
                                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                              />
                              <div className="flex items-center space-x-2">
                                <button
                                  onClick={saveEditExpense}
                                  className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-sm"
                                >
                                  Save
                                </button>
                                <button
                                  onClick={cancelEditExpense}
                                  className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 text-sm"
                                >
                                  Cancel
                                </button>
                              </div>
                            </div>
                          ) : (
                            <div className="flex items-center justify-between">
                              <div className="flex-1">
                                <div className="flex items-center justify-between">
                                  <h4 className="font-medium text-gray-900">{expense.name}</h4>
                                  <span className="font-bold text-gray-900">£{expense.amount}</span>
                                </div>
                                <div className="flex items-center space-x-4 mt-1 text-sm text-gray-600">
                                  <span className="bg-blue-100 text-blue-700 px-2 py-1 rounded">{expense.category}</span>
                                  <span>{expense.frequency}</span>
                                  <span>Due: {formatDate(expense.dueDate)}</span>
                                </div>
                              </div>
                              <div className="ml-3 flex items-center space-x-2">
                                <button
                                  onClick={() => startEditExpense(expense)}
                                  className="text-blue-600 hover:text-blue-800"
                                  title="Edit expense"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </button>
                                <button
                                  onClick={() => deleteExpense(expense.id)}
                                  className="text-red-600 hover:text-red-800"
                                  title="Delete expense"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl shadow-sm border">
                  <div className="px-6 py-4 border-b">
                    <h3 className="text-lg font-semibold">Expenses by Category</h3>
                  </div>
                  <div className="p-6">
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={expensesByCategory}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" angle={-45} textAnchor="end" height={100} />
                        <YAxis />
                        <Tooltip formatter={(value) => [`£${value.toFixed(2)}`, 'Monthly Amount']} />
                        <Bar dataKey="value" fill="#ef4444" />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h3 className="text-lg font-semibold">Upcoming Expenses (Next 7 Days)</h3>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {expenses.filter(exp => exp.dueDate !== 'Ongoing').slice(0, 6).map((expense) => (
                      <div key={expense.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium">{expense.name}</h4>
                          <span className="text-lg font-bold text-red-600">£{expense.amount}</span>
                        </div>
                        <div className="text-sm text-gray-600">
                          <p>Due: {formatDate(expense.dueDate)}</p>
                          <p className="text-blue-600">{expense.category}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'budget' && (
            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-xl font-semibold flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2" />
                    Budget vs Actual
                  </h2>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      {budgets.map((budget, index) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium">{budget.category}</h4>
                            <span className={`text-sm font-medium ${
                              budget.remaining >= 0 ? 'text-green-600' : 'text-red-600'
                            }`}>
                              £{budget.remaining.toFixed(2)} remaining
                            </span>
                          </div>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Allocated: £{budget.allocated}</span>
                              <span>Spent: £{budget.spent.toFixed(2)}</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${
                                  budget.spent > budget.allocated ? 'bg-red-500' : 'bg-blue-600'
                                }`}
                                style={{ width: `${Math.min((budget.spent / budget.allocated) * 100, 100)}%` }}
                              ></div>
                            </div>
                            <div className="text-xs text-gray-600">
                              {((budget.spent / budget.allocated) * 100).toFixed(1)}% used
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-6">
                      <h3 className="text-lg font-medium mb-4">Budget Summary</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Allocated:</span>
                          <span className="font-medium">£{budgets.reduce((sum, b) => sum + b.allocated, 0)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Spent:</span>
                          <span className="font-medium">£{budgets.reduce((sum, b) => sum + b.spent, 0).toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Remaining:</span>
                          <span className={`font-bold ${
                            budgets.reduce((sum, b) => sum + b.remaining, 0) >= 0 ? 'text-green-600' : 'text-red-600'
                          }`}>
                            £{budgets.reduce((sum, b) => sum + b.remaining, 0).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'health' && (
            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-xl font-semibold flex items-center">
                    <Activity className="w-5 h-5 mr-2" />
                    Financial Health Score
                  </h2>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="text-center">
                      <div className="relative w-48 h-48 mx-auto mb-6">
                        <svg className="w-48 h-48 transform -rotate-90">
                          <circle
                            cx="96"
                            cy="96"
                            r="88"
                            stroke="#e5e7eb"
                            strokeWidth="12"
                            fill="none"
                          />
                          <circle
                            cx="96"
                            cy="96"
                            r="88"
                            stroke="#3b82f6"
                            strokeWidth="12"
                            fill="none"
                            strokeLinecap="round"
                            strokeDasharray={`${(financialHealth.score / 100) * 553} 553`}
                          />
                        </svg>
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="text-center">
                            <div className="text-4xl font-bold text-gray-900">{financialHealth.score}</div>
                            <div className="text-sm text-gray-600">out of 100</div>
                          </div>
                        </div>
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900">
                        {financialHealth.score >= 80 ? 'Excellent' :
                         financialHealth.score >= 60 ? 'Good' :
                         financialHealth.score >= 40 ? 'Fair' : 'Needs Improvement'}
                      </h3>
                      <p className="text-gray-600">Financial Health</p>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold">Health Factors</h3>
                      {financialHealth.factors.map((factor, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between">
                            <span className="font-medium">{factor.name}</span>
                            <span className={`text-sm font-medium ${
                              factor.status === 'excellent' ? 'text-green-600' :
                              factor.status === 'good' ? 'text-blue-600' :
                              factor.status === 'okay' ? 'text-yellow-600' : 'text-red-600'
                            }`}>
                              {factor.score}/100
                            </span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${
                                factor.status === 'excellent' ? 'bg-green-500' :
                                factor.status === 'good' ? 'bg-blue-500' :
                                factor.status === 'okay' ? 'bg-yellow-500' : 'bg-red-500'
                              }`}
                              style={{ width: `${factor.score}%` }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="font-semibold text-blue-900 mb-2">Recommendations</h4>
                    <ul className="text-blue-800 text-sm space-y-1">
                      <li>• Continue building your emergency fund to reach 6 months of expenses</li>
                      <li>• Consider increasing investment diversification across different asset classes</li>
                      <li>• Review and optimize your debt-to-income ratio</li>
                      <li>• Maintain your excellent savings rate</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'chat' && (
            <div className="bg-white rounded-xl shadow-sm border h-[700px] flex flex-col">
              <div className="px-6 py-4 border-b">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-xl font-semibold flex items-center">
                      <Brain className="w-5 h-5 mr-2" />
                      AI Financial Assistant
                    </h2>
                    <p className="text-sm text-gray-600">Advanced offline AI with comprehensive financial knowledge</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="text-sm text-green-600 font-medium">Offline AI Active</span>
                  </div>
                </div>
              </div>
              
              <div className="flex-1 p-6 overflow-y-auto space-y-4">
                {chatMessages.length === 0 && (
                  <div className="text-center text-gray-500 mt-20">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Brain className="w-8 h-8 text-blue-600" />
                    </div>
                    <p className="font-medium text-gray-900 mb-2">Ask your offline AI assistant anything!</p>
                    <p className="text-sm mb-4">I have extensive financial knowledge and can analyze your data</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-w-2xl mx-auto">
                      <button 
                        onClick={() => setChatInput("What's my financial health score and what should I improve?")}
                        className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-sm text-blue-700 hover:bg-blue-100"
                      >
                        "What's my financial health score?"
                      </button>
                      <button 
                        onClick={() => setChatInput("How can I optimize my budget and reduce expenses?")}
                        className="bg-green-50 border border-green-200 rounded-lg p-3 text-sm text-green-700 hover:bg-green-100"
                      >
                        "How can I optimize my budget?"
                      </button>
                      <button 
                        onClick={() => setChatInput("Should I prioritize paying off debt or investing more?")}
                        className="bg-purple-50 border border-purple-200 rounded-lg p-3 text-sm text-purple-700 hover:bg-purple-100"
                      >
                        "Debt vs investing strategy?"
                      </button>
                      <button 
                        onClick={() => setChatInput("Give me personalized financial tips based on my data")}
                        className="bg-orange-50 border border-orange-200 rounded-lg p-3 text-sm text-orange-700 hover:bg-orange-100"
                      >
                        "Give me personalized tips"
                      </button>
                    </div>
                  </div>
                )}
                
                {chatMessages.map((message, index) => (
                  <div key={index} className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                      message.role === 'user' 
                        ? 'bg-blue-600 text-white' 
                        : 'bg-gray-100 text-gray-900 border'
                    }`}>
                      {message.role === 'assistant' && (
                        <div className="flex items-center mb-2">
                          <Brain className="w-4 h-4 text-blue-600 mr-2" />
                          <span className="text-xs text-blue-600 font-medium">Offline AI</span>
                        </div>
                      )}
                      <div className="whitespace-pre-wrap">{message.content}</div>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="p-4 border-t bg-gray-50">
                <div className="flex space-x-2">
                  <input
                    type="text"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Ask about budgeting, investing, debt, savings, goals, or get personalized advice..."
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    onClick={handleSendMessage}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium"
                  >
                    Send
                  </button>
                </div>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex items-center space-x-4 text-xs text-gray-500">
                    <span className="flex items-center">
                      <Shield className="w-3 h-3 mr-1" />
                      100% Private & Offline
                    </span>
                    <span className="flex items-center">
                      <Zap className="w-3 h-3 mr-1" />
                      Instant Responses
                    </span>
                    <span className="flex items-center">
                      <BookOpen className="w-3 h-3 mr-1" />
                      Expert Knowledge Base
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'analysis' && (
            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-xl font-semibold flex items-center">
                    <FileSpreadsheet className="w-5 h-5 mr-2" />
                    Excel File Analysis
                  </h2>
                </div>
                <div className="p-6">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                    <Upload className="w-12 h-12 mx-auto text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">Upload Financial Data</h3>
                    <p className="text-gray-600 mb-4">Upload Excel files with transactions, budgets, or investment data</p>
                    <input
                      type="file"
                      accept=".xlsx,.xls,.csv"
                      onChange={handleFileUpload}
                      className="hidden"
                      id="file-upload"
                    />
                    <label htmlFor="file-upload" className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 cursor-pointer">
                      Choose File
                    </label>
                  </div>

                  {isAnalyzing && (
                    <div className="mt-6 text-center">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                      <p className="mt-2 text-gray-600">Analyzing your financial data...</p>
                    </div>
                  )}

                  {uploadedData && (
                    <div className="mt-6 space-y-4">
                      <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                        <h4 className="font-medium text-green-900">{uploadedData.filename}</h4>
                        <p className="text-green-700">{uploadedData.summary}</p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                          <h5 className="font-medium text-blue-900 mb-2">Key Insights</h5>
                          <ul className="space-y-1">
                            {uploadedData.insights.map((insight, index) => (
                              <li key={index} className="text-blue-700 text-sm">• {insight}</li>
                            ))}
                          </ul>
                        </div>

                        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                          <h5 className="font-medium text-purple-900 mb-2">AI Recommendations</h5>
                          <ul className="space-y-1">
                            {uploadedData.recommendations.map((rec, index) => (
                              <li key={index} className="text-purple-700 text-sm">• {rec}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'calculator' && (
            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-xl font-semibold flex items-center">
                    <Calculator className="w-5 h-5 mr-2" />
                    Financial Calculator
                  </h2>
                </div>
                <div className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-lg font-medium mb-4">Compound Interest Calculator</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Initial Investment</label>
                          <input
                            type="number"
                            value={calcInputs.principal}
                            onChange={(e) => setCalcInputs(prev => ({ ...prev, principal: Number(e.target.value) }))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Annual Interest Rate (%)</label>
                          <input
                            type="number"
                            value={calcInputs.rate}
                            onChange={(e) => setCalcInputs(prev => ({ ...prev, rate: Number(e.target.value) }))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Time Period (years)</label>
                          <input
                            type="number"
                            value={calcInputs.time}
                            onChange={(e) => setCalcInputs(prev => ({ ...prev, time: Number(e.target.value) }))}
                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-6">
                      <h3 className="text-lg font-medium mb-4">Results</h3>
                      <div className="space-y-3">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Initial Investment:</span>
                          <span className="font-medium">${calcInputs.principal.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Final Amount:</span>
                          <span className="font-bold text-green-600">${Number(calculateCompoundInterest()).toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Total Interest:</span>
                          <span className="font-medium text-blue-600">
                            ${(Number(calculateCompoundInterest()) - calcInputs.principal).toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'goals' && (
            <div className="space-y-6">
              <div className="bg-white rounded-xl shadow-sm border">
                <div className="px-6 py-4 border-b">
                  <h2 className="text-xl font-semibold flex items-center">
                    <Target className="w-5 h-5 mr-2" />
                    Financial Goals
                  </h2>
                </div>
                <div className="p-6 space-y-6">
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Emergency Fund</h4>
                      <span className="text-sm text-gray-600">75% Complete</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
                      <div className="bg-green-600 h-3 rounded-full" style={{ width: '75%' }}></div>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>£15,000 saved</span>
                      <span>Goal: £20,000</span>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">House Down Payment</h4>
                      <span className="text-sm text-gray-600">45% Complete</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
                      <div className="bg-blue-600 h-3 rounded-full" style={{ width: '45%' }}></div>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>£45,000 saved</span>
                      <span>Goal: £100,000</span>
                    </div>
                  </div>

                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">Retirement (401k)</h4>
                      <span className="text-sm text-gray-600">On Track</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
                      <div className="bg-purple-600 h-3 rounded-full" style={{ width: '65%' }}></div>
                    </div>
                    <div className="flex justify-between text-sm text-gray-600">
                      <span>£325,000 saved</span>
                      <span>Goal: £500,000 by 50</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default AIFinancialApp;